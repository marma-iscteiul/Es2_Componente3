package complemento2.complemento2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class teste1 {

	Testeee t;
	@BeforeEach
	void setUp() throws Exception {
		t= new Testeee ();
	}

	

	@Test
	public void testTesteee()
	{
		assertTrue( true );
	}
	
	@Test
	final void testMain() {
		t.main(null);
	}
	
}
