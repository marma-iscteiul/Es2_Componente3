package complemento2.complemento2;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.apache.commons.mail.EmailException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Teste {

	
	App a;
	Testeee t;
	@BeforeEach
	void setUp() throws Exception {
		a = new App();
		t = new Testeee();
	}
	

	@Test
	final void testMain() throws EmailException, IOException, InterruptedException {
		
		a=new App();
		a.main(null);
	
//		a.login();
//		a.forms();
//		a.repositories();
//		a.contact();
	}

	@Test
	final void testWebPage() {
		a.WebPage();
	}

	@Test
	final void testLogin() throws EmailException {
		a.login();
	}

	@Test
	final void testForms() {
		a.forms();
	}

	@Test
	final void testRepositories() {
		a.repositories();
	}

	@Test
	final void testContact() {
		a.contact();
	}

	@Test
	final void testErros() throws EmailException {
		a.erros();
	}

	@Test
	final void testTabela() {
		a.tabela();
	}

	@Test
	final void testTabela2() throws IOException {
		a.tabela2();
	}


}
