package complemento2.complemento2;


import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.sql.rowset.WebRowSet;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;

// TODO: Auto-generated Javadoc
/**
 * The Class App.
 */
public class App {

	/** The driver. */
	public static WebDriver driver;
	
	/** The website. */
	public static String website = "http://192.168.99.100";
	
	/** The title web page. */
	public static String titleWebPage = "es2 – Just another WordPress site";
	//	public static String Username = "bea";
	/** The Username. */
	//	public static String Password = "teste";
	public static String Username = "blaso1";
	
	/** The Password. */
	public static String Password = "beaadmin";

	/** The up. */
	public static Boolean up = false;
	
	/** The erro. */
	public static String erro = null;
	
	/** The email admin. */
	public static String emailAdmin = "bea.abrantes99@gmail.com";

	/** The teste. */
	public static Testeee teste;

	/** The loginup. */
	public static Boolean loginup = false;
	
	/** The formsup. */
	public static Boolean formsup = false;
	
	/** The repoisitoryup. */
	public static Boolean repoisitoryup = false;

	/** The webpages. */
	public static String webpages = "Down";
	
	/** The logindone. */
	public static String logindone = "Login Done";
	
	/** The Forms list. */
	public static String FormsList = "Forms Error";
	
	/** The Content repository. */
	public static String ContentRepository = "Repository Error";

	/** The enviou 1. */
	public static Boolean enviou1 = false;
	
	/** The enviou 2. */
	public static Boolean enviou2 = false;
	
	/** The enviou 3. */
	public static Boolean enviou3 = false;
	
	/** The enviou 4. */
	public static Boolean enviou4 = false;
	
	/** The enviou 5. */
	public static Boolean enviou5 = false;
	
	/** The enviou 6. */
	public static Boolean enviou6 = false;
	
	/** The enviou 7. */
	public static Boolean enviou7 = false;
	
	/** The Email. */
	public static String Email ="Waiting";
	
	/** The pagina. */
	public static String pagina ="Down";

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws EmailException the email exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws InterruptedException the interrupted exception
	 */
	public static void main( String[] args ) throws EmailException, IOException, InterruptedException{
		while (true) {
		System.setProperty("webdriver.chrome.driver", "C:\\webdrivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to(website);
		driver.manage().window().maximize();
		WebPage();

		if(up==true) {
			login();
			Thread.sleep(500);
			forms();
			Thread.sleep(500);
			repositories();
			Thread.sleep(500);
			contact();


		}

		if (up == true && loginup == true && repoisitoryup == true && formsup == true) {
			webpages = "All Up";
			System.out.println(webpages);	
		}
		if(erro==" a página Web está em baixo " && enviou1==true 
				||erro==" a página do login está em baixo " && enviou2==true
				||erro== " algo falhou ao efetuar o login "&& enviou3==true 
				||erro== " a página dos forms está em baixo "&& enviou4==true 
				||erro== " a página dos repositories está em baixo "&& enviou5==true 
				||erro== " existem contéudos em falta nos repositórios "&& enviou6==true){
			Email="Working";
		}else {
			Email="Not Working";
		}

		tabela();
		tabela2();

		//			driver.findElement(By.linkText("es2")).click();
		//			driver.findElement(By.linkText("Es 2 :)")).click();
		//			
		//			driver.findElement(By.linkText("Table here :)")).click();


		driver.close();
		Thread.sleep(7200000);
		}
	}

	/**
	 * Web page.
	 */
	public static void WebPage() {

		try {
			String title = driver.getTitle();
			if (title.equals(titleWebPage)) {
				System.out.println("Webpage up :) ");
				up = true;
				pagina ="Up";
			}else {
				System.out.println("Webpage down :( ");
				erro = " a página Web está em baixo ";

				erros();
				enviou1 = true;

			}

		} catch (Exception e) {
			//System.out.println("Webpage down :(( ");
		}
	}

	/**
	 * Login.
	 *
	 * @throws EmailException the email exception
	 */
	public static void login() throws EmailException { 
		try {


			Actions action = new Actions (driver);

			WebElement login = driver.findElement(By.linkText("Log in"));
			((RemoteWebDriver) driver).executeScript("arguments[0].scrollIntoView()", login);
			Thread.sleep(1000);

			action.moveToElement(driver.findElement(By.linkText("Log in"))).click().perform();
			Thread.sleep(1000);

			String title = driver.getTitle();
			String loginTitle = "Log In ‹ es2 — WordPress";

			if (title.equals(loginTitle)) {
				System.out.println("Login up");
				loginup = true;

			}else {
				System.out.println("Login Down");
				erro = " a página do login está em baixo ";
				erros();
				enviou2 = true;
			}

			WebElement username = driver.findElement(By.id("user_login"));
			username.sendKeys(Username);

			WebElement password = driver.findElement(By.id("user_pass"));
			password.sendKeys(Password);

			WebElement click = driver.findElement(By.id("wp-submit"));
			click.click();
			Thread.sleep(1000);


			try {
				driver.findElement(By.id("login_error"));
				logindone = "Login Error";
				//System.out.println("Login Errado");
				erro = " algo falhou ao efetuar o login ";

				erros();
				enviou3 = true;
			} catch (Exception e) {


			}

		} catch (Exception e) {
			//System.out.println("errou ainda mais");

		}

	}


	/**
	 * Forms.
	 */
	public static void forms() {
		try {	
			driver.findElement(By.linkText("Users")).click();


			String title = driver.getTitle();
			String FormsTitle = "Users ‹ es2 — WordPress";


			if (title.equals(FormsTitle)) {
				System.out.println("Forms up");
				formsup = true;
				FormsList = "Forms Listed";
			}else {
				System.out.println("Forms Down");
				erro = " a página dos forms está em baixo ";
				erros();
				enviou4=true;
			}

			WebElement form = driver.findElement(By.id("the-list"));	

			String users = form.getText();
			System.out.println("A lista de users registados no site é: " + users);
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * Repositories.
	 */
	public static void repositories() {
		try {
			System.out.println("ola");
			driver.findElement(By.linkText("es2")).click();

			driver.findElement(By.linkText("Repository")).click();

			String title = driver.getTitle();
			String RepositoriesTitle = "Repository – es2";

			if (title.equals(RepositoriesTitle)) {
				System.out.println("repository up ");
				repoisitoryup = true;
							}else {
				System.out.println("repository down ");
				erro = " a página dos repositories está em baixo ";
				erros();
				enviou5=true;
			}

			try {

				driver.findElement(By.linkText("biology-09-00094-2"));
				driver.findElement(By.linkText("biology-09-00097-2"));
				driver.findElement(By.linkText("1-s2.0-S1755436517301135-main-1"));
				driver.findElement(By.linkText("178-1-53-2"));
				ContentRepository = "Rigth Content";

			} catch (Exception e) {
				// TODO: handle exception
				erro = " existem contéudos em falta nos repositórios ";
				erros();
				enviou6=true;
			}


		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * Contact.
	 */
	public static void contact () {
		try {
			//driver.findElement(By.linkText("es2")).click();

			driver.findElement(By.linkText("Contact us")).click();

			String title = driver.getTitle();
			String ContactUsTitle = "Contact us – es2";

			if (title.equals(ContactUsTitle)) {
				System.out.println("Contact us up ");
				//repoisitoryup = true;
				//ContentRepository = "Rigth Content";
			}else {
				System.out.println("Contact us down ");
				erro = " a página de contactos está em baixo ";
				erros();
				//enviou5=true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}


	/**
	 * Erros.
	 *
	 * @throws EmailException the email exception
	 */
	public static void erros () throws EmailException{

		Email email = new SimpleEmail();
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(465);
		email.setAuthenticator(new DefaultAuthenticator("complementodoisesII@gmail.com", "ComplementoDois"));
		email.setSSLOnConnect(true);
		email.setFrom("complementodoisesII@gmail.com");
		email.setSubject("Ocorreu um Erro!");
		email.setMsg("Ocorreu um erro pois" + erro + ".");
		email.addTo(emailAdmin);
		email.send();

	}

	/**
	 * Tabela.
	 */
	public static void tabela () {

		System.out.println( "Content-type: text/html\n");
		System.out.println( "<head>\n" );
		System.out.println( "<title>Tabela de monotorizacao!</title>\n" );
		System.out.println( "</head>\n" );
		System.out.println( "<body>\n" );
		System.out.println( "<table width=\"800px\" border=\"1px\">\n" );
		System.out.println( "<caption>Tabela de monotorizacao! </caption>\n" );
		System.out.println( "<tr align=\"left\" bgcolor=\"lightblue\">\n" );
		System.out.println( "<th>Web Page</th>\n" );
		System.out.println( "<th>Login</th>\n" );
		System.out.println( "<th>Forms</th>\n" );
		System.out.println( "<th>Repositories</th>\n" );
		System.out.println( "<th>E-mail</th>\n" );
		System.out.println( "<th>General</th>\n" );
		System.out.println( "</tr>\n" );
		System.out.println( "<tr>\n" );
		System.out.println( "<td>"+ pagina +"</td>\n" );
		System.out.println( "<td>"+ logindone +"</td>\n" );
		System.out.println( "<td>" + FormsList + "</td>\n" );
		System.out.println( "<td>"+ContentRepository+"</td>\n" );
		System.out.println( "<td>"+Email+"</td>\n" );
		System.out.println( "<td>"+webpages+"</td>\n" );
		System.out.println( "</tr>\n" );
		System.out.println( "</table>\n" );
		System.out.println( "</body>\n" );

	}

	/**
	 * Tabela 2.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void tabela2 () throws IOException {


		BufferedWriter bw2 = new BufferedWriter(new FileWriter("ola.html"));
		bw2.write( "<html>\r\n" +
				"<head>\n" +
				"<title>Tabela de monotorizacao!</title>\r\n" +
				"</head>\r\n" +
				"<body>\r\n" +
				"<table width=\"800px\" border=\"1px\">\r\n" +
				"<caption>Tabela de monotorizacao! </caption>\r\n" +
				"<tr align=\"left\" bgcolor=\"lightblue\">\r\n" +
				"<th>Web Page</th>\r\n" +
				"<th>Login</th>\r\n" +
				"<th>Forms</th>\r\n" +
				"<th>Repositories</th>\r\n" +
				"<th>E-mail</th>\r\n" +
				"<th>General</th>\r\n" +
				"</tr>\r\n" +
				"<tr>\r\n" +
				"<td>"+ pagina +"</td>\r\n" +
				"<td>"+ logindone +"</td>\r\n" +
				"<td>" + FormsList + "</td>\r\n" +
				"<td>"+ContentRepository+"</td>\r\n" +
				"<td>"+Email+"</td>\r\n" +
				"<td>"+webpages+"</td>\r\n" +
				"</tr>\r\n" +
				"</table>\r\n" +
				"</body>\r\n" +
				"</html>");

		bw2.close();


	}
}
