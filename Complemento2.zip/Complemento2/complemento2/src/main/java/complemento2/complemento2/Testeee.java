package complemento2.complemento2;

// TODO: Auto-generated Javadoc
/**
 * The Class Testeee.
 */
public class Testeee {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

		
		System.out.println( "Content-type: text/html\n");
		System.out.println( "<head>\n" );
		System.out.println( "<title>Tabela de monotorizacao!</title>\n" );
		System.out.println( "</head>\n" );
		System.out.println( "<body>\n" );
		System.out.println( "<table width=\"800px\" border=\"1px\">\n" );
		System.out.println( "<caption>Tabela de monotorizacao! </caption>\n" );
		System.out.println( "<tr align=\"left\" bgcolor=\"lightblue\">\n" );
		System.out.println( "<th>Web Pages</th>\n" );
		System.out.println( "<th>Login</th>\n" );
		System.out.println( "<th>Forms</th>\n" );
		System.out.println( "<th>Repositories</th>\n" );
		System.out.println( "<th>E-mail</th>\n" );
		System.out.println( "<th>Date</th>\n" );
		System.out.println( "<th>General</th>\n" );
		System.out.println( "</tr>\n" );
		System.out.println( "<tr>\n" );
		System.out.println( "<td>Up</td>\n" );
		System.out.println( "<td>Login Done</td>\n" );
		System.out.println( "<td>Forms listed</td>\n" );
		System.out.println( "<td>Rigth content</td>\n" );
		System.out.println( "<td>Working</td>\n" );
		System.out.println( "<td>check</td>\n" );
		System.out.println( "<td>All up</td>\n" );
		System.out.println( "</tr>\n" );
		System.out.println( "</table>\n" );
		System.out.println( "</body>\n" );

	}
	
}
